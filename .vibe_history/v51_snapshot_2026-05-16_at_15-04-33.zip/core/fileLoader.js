// File: cs/fileLoader.js
/**
 * fileLoader.js
 * Handles loading files, initial parsing (like product info),
 * and triggering the skin detection/loading process.
 * ADDED: Toast notification for missing product.xml.
 * MODIFIED: Commented out premature updateProductLogo() call to prevent early logo removal.
 */
import * as State from './state.js';
import { addConsoleLogEntry, getFileContent, setProductName, setProductVendor, clearAllState, getFileMap, getImageBlobUrls, getFontBlobUrls, normalizePath as stateNormalizePath } from './state.js'; // Use state's normalizePath
import {
    // Import GETTER functions and utilities
    getStatusDiv, logError, clearErrors, getGuiContentWrapper, getSkinSelector,
    getSkinSelectorContainer, getZoomSlider, getZoomValueDisplay, getFileTreeContainer,
    getPreviewArea, getEditButton, getSclFileInput, getProductLogoImg,
    // Import Utility functions
    updateStatus, normalizePath, // Import normalizePath from domUtils (delegates to state)
    showToast // <<< ADDED showToast import
} from './domUtils.js';
import { detectSkins, populateSkinSelector, loadSkin, updateProductLogo } from './skinManager.js';

// Store the actual path found for product.xml
let productXmlPath = null;

/**
 * Main function to handle user selecting files/folder.
 * Uses async/await for better flow control.
 * @param {FileList | null} files - The list of files from the input event.
 */
export async function handleFileSelection(files) {
    console.log('[FL] === handleFileSelection START ===');
    clearErrors();
    const statusDiv = getStatusDiv();

    if (!files || files.length === 0) { 
        if (statusDiv) updateStatus('No folder selected or no files found.', 5000); 
        console.log('[FL] No files selected.'); 
        return; 
    }

    // Non-destructive Guard Clause: Validate product.xml presence BEFORE wiping state or UI canvas wrappers
    const hasProductXml = Array.from(files).some(file => {
        const lowerName = file.name.toLowerCase();
        const lowerPath = (file.webkitRelativePath || '').toLowerCase();
        return lowerName === 'product.xml' || lowerPath.endsWith('/product.xml');
    });

    if (!hasProductXml) {
        if (statusDiv) updateStatus('Please choose a chip<b>synth</b> root folder to start.', 6000);
        showToast('Please choose a chip<b>synth</b> root folder to start.', 'error', 6000);
        return;
    }

    if (statusDiv) updateStatus('Processing files...', 0);

    console.log('[FL] Clearing previous state...');
    clearAllState();
    productXmlPath = null; // Reset path on new load

    // --- Clear UI elements safely using getters now that we verified valid product context ---
    const guiContentWrapper = getGuiContentWrapper(); if (guiContentWrapper) guiContentWrapper.innerHTML = '';
    const skinSelector = getSkinSelector(); if (skinSelector) skinSelector.innerHTML = '';
    const skinSelectorContainer = getSkinSelectorContainer(); if (skinSelectorContainer) skinSelectorContainer.style.display = 'none';
    const fileTreeContainer = getFileTreeContainer(); if (fileTreeContainer) fileTreeContainer.innerHTML = '';
    const previewArea = getPreviewArea(); if (previewArea) previewArea.innerHTML = 'Click a file in the browser to preview.';
    const editButton = getEditButton(); if (editButton) editButton.disabled = true;
    const zoomSlider = getZoomSlider(); if (zoomSlider) zoomSlider.value = 1;
    if (guiContentWrapper) guiContentWrapper.style.transform = 'scale(1)';
    const zoomValueDisplay = getZoomValueDisplay(); if (zoomValueDisplay) zoomValueDisplay.textContent = '100%';
    const productLogoImg = getProductLogoImg(); if (productLogoImg) { productLogoImg.src = ''; productLogoImg.style.display = 'none'; }
    console.log('[FL] UI elements cleared.');

    console.log(`[FL] Processing ${files.length} file entries...`);
    if (statusDiv) updateStatus(`Processing ${files.length} files...`, 0);

    const promises = Array.from(files).map(file => readFileAndStore(file, file.webkitRelativePath || file.name));
    console.log(`[FL] Created ${promises.length} file reading promises.`);

    try {
        console.log('[FL] --- Awaiting Promise.all()... ---');
        await Promise.all(promises);
        console.log('[FL] --- Promise.all() COMPLETED ---');

        const fileMap = State.getFileMap();
        const fileMapKeysForDebug = Array.from(fileMap.keys());
        console.log(`[FL: Debug] fileMap keys AFTER promise.all (${fileMapKeysForDebug.length}):`);
        // fileMapKeysForDebug.forEach(key => console.log(`    '${key}'`)); // Optionally log all keys

        // --- Find product.xml path ---
        productXmlPath = fileMapKeysForDebug.find(key => key.endsWith('/product.xml') || key === 'product.xml');
        console.log(`[FL: Debug] Found product.xml path?: '${productXmlPath || 'Not found'}'`);

        const imageCount = getImageBlobUrls().size, fontCount = getFontBlobUrls().size;
        if(statusDiv) updateStatus(`Processed ${fileMapKeysForDebug.length} text, ${imageCount} img, ${fontCount} font. Detecting skins...`, 0);

        parseProductInfoFromXml(); // Now uses productXmlPath
        // try { updateProductLogo(); } catch (logoError) { logError("Logo Update Error", logoError); } // MODIFICATION: Commented out. This premature call removes the logo img tag.
        // The main updateProductLogo call happens after buildGui in skinManager.js's loadSkin function.
        // Keeping this call active causes the #product-logo-img element to be removed from the DOM before it's properly used.

        detectSkins(productXmlPath); // Pass the found path to detectSkins
        populateSkinSelector();

        const roots = State.getDetectedSkinInfo();
        console.log('[FL] Detected skin info objects:', roots);

        if (Array.isArray(roots) && roots.length > 0 && typeof roots[0]?.root === 'string') {
            const initialSkinRoot = roots[0].root;
            console.log(`[FL] -> Calling loadSkin for initial root dir: '${initialSkinRoot || "Default(root)"}'...`);
            loadSkin(initialSkinRoot);
        } else {
             console.error('[FL] No valid skin roots detected or invalid structure:', roots);
             addConsoleLogEntry('No valid skin roots detected after processing or invalid data structure.', 'error');
             // Check if product.xml was missing, specific error handled in parseProductInfoFromXml now
             // If product.xml *was* found but detection still failed, show generic error.
             if (productXmlPath) {
                 showToast('No valid skins found in the uploaded folder.', 'error');
                 throw new Error('No valid skin found or invalid root data.');
             }
             // If product.xml was *not* found, the toast is already shown, just throw error
             else {
                 throw new Error('product.xml missing, cannot detect skins.');
             }
        }
        console.log('[FL] handleFileSelection positive path finished.');

    } catch (err) {
        console.error('[FL] --- Error during file processing or skin loading ---', err);
        if (err.message && err.message.includes('product.xml missing')) {
            if (statusDiv) updateStatus('Please choose a chip<b>synth</b> root folder to start.', 6000);
            showToast('Please choose a chip<b>synth</b> root folder to start.', 'error', 6000);
        } else {
            logError('Error during file processing/loading', err);
            addConsoleLogEntry(`Error during file processing/loading: ${err.message || err}`, 'error');
            if (statusDiv) updateStatus('Error processing files or loading skin. Check console.', 5000);
        }
    }

    console.log('[FL] === handleFileSelection END ===');
}

/** Reads a single file and stores its content or blob URL in state */
export function readFileAndStore(file, path) {
     const NORM_PATH = stateNormalizePath(path);
     return new Promise((resolve, reject) => {
         try {
             let keyPath;
             // Use webkitRelativePath if available (folder structure), otherwise just the filename
             if (file.webkitRelativePath) {
                 keyPath = stateNormalizePath(file.webkitRelativePath);
             } else {
                 keyPath = stateNormalizePath(file.name);
             }

             if (!keyPath) {
                 console.warn(`[FL readFileAndStore] Skipping file with empty keyPath (Original path: ${path})`);
                 resolve();
                 return;
             }

             const lowerFileName = file.name.toLowerCase();
             const storeKey = keyPath; // Use the calculated path as the key

             // --- UPDATED: Added .png, .html, .fermatax, .fermatap ---
             if (/\.(svg|png|jpg|jpeg|gif)$/i.test(lowerFileName)) {
                 const blobUrl = URL.createObjectURL(file);
                 State.addImageBlobUrl(storeKey, blobUrl);
                 // console.log(`[FL] Stored Image: ${storeKey} -> ${blobUrl.substring(0, 20)}...`);
                 resolve();
             } else if (/\.(ttf|otf)$/i.test(lowerFileName)) {
                 const blobUrl = URL.createObjectURL(file);
                 State.addFontBlobUrl(storeKey, blobUrl);
                 // console.log(`[FL] Stored Font: ${storeKey} -> ${blobUrl.substring(0, 20)}...`);
                 resolve();
             } else if (lowerFileName.endsWith('.xml') || lowerFileName.endsWith('.txt') || lowerFileName.endsWith('.scl') || lowerFileName.endsWith('.html') || lowerFileName.endsWith('.fermatax') || lowerFileName.endsWith('.fermatap')) {
                 const reader = new FileReader();
                 reader.onload = (event) => {
                     State.addFile(storeKey, event.target.result);
                     // console.log(`[FL] Stored Text: ${storeKey} (${(event.target.result?.length || 0)} chars)`);
                     resolve();
                 };
                 reader.onerror = (error) => {
                     logError(`FileReader error for ${NORM_PATH}`, error);
                     reject(error);
                 };
                 reader.readAsText(file);
             } else {
                 // console.log(`[FL] Skipping unsupported file type: ${storeKey}`);
                 resolve(); // Resolve for unsupported types, don't reject
             }
         } catch (e) {
             logError(`Exception processing file ${NORM_PATH}`, e);
             reject(e);
         }
     });
}

/** Parses product.xml to extract vendor and product name */
function parseProductInfoFromXml() {
    console.log('[FL] parseProductInfoFromXml executing...');
    const content = productXmlPath ? State.getFileMap().get(productXmlPath) : undefined;
    let productName = 'Product (Name Missing)';
    let vendorName = 'Vendor (Name Missing)';

    if (content) {
        console.log(`[FL] Found product.xml content using key: '${productXmlPath}'`);
        addConsoleLogEntry(`Found product.xml at '${productXmlPath}'. Parsing...`, 'info');
        try {
             const parser = new DOMParser();
             const xmlDoc = parser.parseFromString(content, "application/xml");
             const parseError = xmlDoc.querySelector("parsererror");
             if (parseError) { throw new Error(parseError.textContent); }

             // --- ADDED Detailed Logging ---
             // console.log('[FL: Debug] Searching for vendor/product properties...');
             const productProp = xmlDoc.querySelector('Setup > Property[name="product"]');
             const vendorProp = xmlDoc.querySelector('Setup > Property[name="vendor"]');
             // console.log(`[FL: Debug] productProp found?:`, productProp);
             // console.log(`[FL: Debug] vendorProp found?:`, vendorProp);

             if (productProp) {
                 const productValue = productProp.getAttribute('value');
                 // console.log(`[FL: Debug] productProp value attribute: '${productValue}'`);
                 productName = productValue || productName;
             } else {
                 console.warn("[FL] Query 'Setup > Property[name=\"product\"]' returned null.");
                 addConsoleLogEntry("Property 'product' missing in product.xml", 'warn');
             }
             if (vendorProp) {
                 const vendorValue = vendorProp.getAttribute('value');
                 // console.log(`[FL: Debug] vendorProp value attribute: '${vendorValue}'`);
                 vendorName = vendorValue || vendorName;
             } else {
                 console.warn("[FL] Query 'Setup > Property[name=\"vendor\"]' returned null.");
                 addConsoleLogEntry("Property 'vendor' missing in product.xml", 'warn');
             }
             // --- END Detailed Logging ---

        } catch (e) {
            console.error("[FL] Exception parsing product.xml:", e); logError("Exception parsing product.xml", e); addConsoleLogEntry(`Exception parsing product.xml: ${e.message}`, 'error'); productName = 'Product (Parse Exception)'; vendorName = 'Vendor (Parse Exception)';
        }
    } else {
        console.warn(`[FL] product.xml content not found (expected path: ${productXmlPath || "'Not Found'"}). Cannot parse product/vendor names.`);
        addConsoleLogEntry(`product.xml not found at expected path: ${productXmlPath || "'Not Found'"}.`, 'warn');
        productName = 'Product (Not Found)'; vendorName = 'Vendor (Not Found)';
    }
    setProductName(productName);
    setProductVendor(vendorName);
    console.log(`[FL] Product info set - Vendor: ${vendorName}, Product: ${productName}`);
}

/** Handles SCL file selection */
export function handleSclFileSelect(event) {
    // ...(Function unchanged, uses getters) ...
     console.log("[FL] handleSclFileSelect triggered."); const file = event.target?.files?.[0]; const guiContentWrapper = getGuiContentWrapper(); const label = guiContentWrapper?.querySelector('[data-param="DID_SCALANAME"]') || document.querySelector('[data-param="DID_SCALANAME"]'); if (file && label) { console.log(`[FL] SCL file selected: ${file.name}`); label.textContent = file.name; label.dataset.loadedFilename = file.name; addConsoleLogEntry(`Loaded Scala file: ${file.name}`, 'info'); showToast(`Loaded scale: ${file.name}`, 'info'); } else if (file && !label) { console.warn("[FL] SCL file loaded, but Scala name label (DID_SCALANAME) missing in current GUI."); addConsoleLogEntry(`Loaded Scala file: ${file.name} (Label not found)`, 'warn'); showToast(`Loaded scale: ${file.name} (Label not found in UI)`, 'info'); } if (event.target) event.target.value = null;
}