// File: cs/renderers/sliderRenderer.js
import * as DomUtils from '../core/domUtils.js';
import * as State from '../core/state.js';

export function renderCS01Slider(xmlNode, mergedAttributes, currentParams, sourcePath) {
    const htmlElement = document.createElement('div');
    htmlElement.classList.add('gui-slider-container');

    // Case-insensitive attribute extraction
    const parsedBoxColor = DomUtils.parseColor(mergedAttributes['boxColor'] || mergedAttributes['boxcolor'] || '#23232300');
    htmlElement.style.backgroundColor = parsedBoxColor;

    const paramId = DomUtils.getParamValue(xmlNode, currentParams.paramOffset);
    const vmin = parseFloat(mergedAttributes['vmin'] || 0);
    const vmax = parseFloat(mergedAttributes['vmax'] || 1);
    let vdefault_from_xml = parseFloat(mergedAttributes['vdefault'] || vmin);

    const springMode = mergedAttributes['spring_mode'] === '1';
    const spring_default_to_center = mergedAttributes['spring_default_to_center'] === '1';

    let vdefault_for_display_and_ctrl_click = DomUtils.clamp(vdefault_from_xml, vmin, vmax);
    if (springMode && spring_default_to_center && vmin < 0 && vmax > 0) {
        vdefault_for_display_and_ctrl_click = 0;
    }
    vdefault_for_display_and_ctrl_click = DomUtils.clamp(vdefault_for_display_and_ctrl_click, vmin, vmax);

    const alwaysShowText = mergedAttributes['show_text'] === '1' || mergedAttributes['showtext'] === '1';
    const textEditEnabled = mergedAttributes['textEdit_enabled'] === '1';
    const clickOnTrack = mergedAttributes['clickOnTrack'] === '1';

    const containerW = parseFloat(mergedAttributes['w'] || 0);
    const containerH = parseFloat(mergedAttributes['h'] || 0);

    const knobWValueFromAttrs = mergedAttributes['knob_w'];
    const knobW = parseFloat(knobWValueFromAttrs || containerW);

    let knobX;
    const knobXValueFromAttrs = mergedAttributes['knob_x'];
    if (knobXValueFromAttrs && String(knobXValueFromAttrs).toLowerCase() === 'center') {
        knobX = (containerW - knobW) / 2;
    } else {
        knobX = parseFloat(knobXValueFromAttrs || 0);
    }

    const knobY = parseFloat(mergedAttributes['knob_y'] || 0);
    const knobH = parseFloat(mergedAttributes['knob_h'] || 4);
    
    // Robust color extraction ignoring case
    const knobColor = DomUtils.parseColor(mergedAttributes['knobColor'] || mergedAttributes['knobcolor'] || '#696969FF');
    const fillColor = DomUtils.parseColor(mergedAttributes['fillColor'] || mergedAttributes['fillcolor'] || 'transparent');

    htmlElement.dataset.param = paramId || '';
    htmlElement.dataset.vmin = vmin;
    htmlElement.dataset.vmax = vmax;
    htmlElement.dataset.vdefault = vdefault_for_display_and_ctrl_click;
    htmlElement.dataset.trueXmlVdefault = DomUtils.clamp(vdefault_from_xml, vmin, vmax);
    htmlElement.dataset.springMode = springMode ? '1' : '0';
    htmlElement.dataset.springDefaultToCenter = spring_default_to_center ? '1' : '0';
    htmlElement.dataset.showText = alwaysShowText ? '1' : '0';
    htmlElement.dataset.textEditEnabled = textEditEnabled ? '1' : '0';
    htmlElement.dataset.clickOnTrack = clickOnTrack ? '1' : '0';
    htmlElement.dataset.currentValue = vdefault_for_display_and_ctrl_click;
    htmlElement.dataset.xmlAttr_stepped = mergedAttributes['stepped'] || '0';
    htmlElement.dataset.xmlAttr_valueText_format = mergedAttributes['valueText_format'] || '';
    htmlElement.dataset.containerH = containerH;
    htmlElement.dataset.knobH = knobH;
    htmlElement.dataset.knobY = knobY;

    // 1. Create the dynamic active fill element (drawn behind the knob)
    const fill = document.createElement('div');
    fill.classList.add('gui-slider-fill');
    fill.style.position = 'absolute';
    fill.style.left = '0px';
    fill.style.bottom = '0px';
    fill.style.width = '100%';
    fill.style.backgroundColor = fillColor;
    fill.style.pointerEvents = 'none'; // Clicks must pass through to the main track area
    htmlElement.appendChild(fill);

    // 2. Create the draggable knob element
    const knob = document.createElement('div');
    knob.classList.add('gui-slider-knob');
    knob.style.position = 'absolute';
    knob.style.left = `${knobX}px`;
    knob.style.width = `${knobW}px`;
    knob.style.height = `${knobH}px`;
    knob.style.backgroundColor = knobColor;
    knob.style.cursor = 'grab';
    knob.style.zIndex = '2'; // Ensures the knob stays on top of the fill layer

    // 3. Create the Value Tooltip
    // By appending the tooltip directly inside the knob, it automatically moves with it!
    const valueText = document.createElement('span');
    valueText.classList.add('slider-value-text');
    valueText.textContent = DomUtils.formatDisplayValue(vdefault_for_display_and_ctrl_click, mergedAttributes['valueText_format'], vmin, vmax);
    
    // Center the text perfectly over the knob's bounding box
    valueText.style.position = 'absolute';
    valueText.style.top = '50%';
    valueText.style.left = '50%';
    valueText.style.transform = 'translate(-50%, -50%)';
    valueText.style.pointerEvents = 'none';
    valueText.style.transition = 'opacity 0.15s ease-in-out';
    valueText.style.backgroundColor = 'rgba(25, 27, 33, 0.85)';
    valueText.style.border = '1px solid #444';
    valueText.style.padding = '2px 6px';
    valueText.style.borderRadius = '3px';
    valueText.style.whiteSpace = 'nowrap';
    valueText.style.zIndex = '10';

    if (alwaysShowText) {
        valueText.style.opacity = '1';
    } else {
        valueText.style.opacity = '0';
        knob.addEventListener('mouseenter', () => valueText.style.opacity = '1');
        knob.addEventListener('mouseleave', () => valueText.style.opacity = '0');
    }

    knob.appendChild(valueText);
    htmlElement.appendChild(knob);

    // 4. Visual Synchronization Engine
    const syncSliderVisuals = () => {
        let val = parseFloat(htmlElement.dataset.currentValue);
        if (isNaN(val)) val = vdefault_for_display_and_ctrl_click;

        const valueRange = vmax - vmin;
        let normalizedValue = valueRange !== 0 ? (val - vmin) / valueRange : 0;
        const safeTrackHeight = Math.max(0, containerH - knobH);
        
        let calculatedKnobTop = DomUtils.clamp((1 - normalizedValue) * safeTrackHeight, 0, safeTrackHeight);
        let finalKnobPosition = DomUtils.clamp(calculatedKnobTop + knobY, 0, Math.max(0, containerH - knobH));
        
        // Update knob top if it was triggered by a programmatic data change
        const currentKnobTop = parseFloat(knob.style.top) || 0;
        if (Math.abs(currentKnobTop - finalKnobPosition) > 0.5) {
            knob.style.top = `${finalKnobPosition}px`;
        }

        // Always recalculate the fill directly from the physical knob position
        const realKnobTop = parseFloat(knob.style.top) || finalKnobPosition;
        const fillHeight = containerH - realKnobTop - (knobH / 2);
        fill.style.height = `${Math.max(0, fillHeight)}px`;
        
        // Update the active text string
        valueText.textContent = DomUtils.formatDisplayValue(val, htmlElement.dataset.xmlAttr_valueText_format, vmin, vmax);
    };

    // Make the sync function externally accessible for your state manager
    htmlElement.updateVisualState = syncSliderVisuals;
    syncSliderVisuals(); // Execute once to draw initial state

    // Attach an observer so external drag scripts automatically update the fill and text 
    // seamlessly whether they change knob.style.top OR data-current-value directly
    const observer = new MutationObserver(syncSliderVisuals);
    observer.observe(knob, { attributes: true, attributeFilter: ['style'] });
    observer.observe(htmlElement, { attributes: true, attributeFilter: ['data-current-value'] });

    const postProcessFunction = (element, attrs, params, sourceXmlNode, styleNameString) => {
        const knobElement = element.querySelector('.gui-slider-knob');
        const valueTextElement = knobElement?.querySelector('.slider-value-text');
        if (valueTextElement) {
            const fontAlias = attrs['font'];
            if (fontAlias) DomUtils.applyFont(valueTextElement, fontAlias);

            const textColor = attrs['color_text'] || attrs['fontColor'];
            if (textColor) valueTextElement.style.color = DomUtils.parseColor(textColor);
        }
    };

    return {
        htmlElement: htmlElement,
        mainElementForAttributes: htmlElement,
        requiresRecursiveRender: false,
        postProcessFunction: postProcessFunction
    };
}

export function renderCS03Slider(xmlNode, mergedAttributes, currentParams, sourcePath) {
    const htmlElement = document.createElement('div');
    htmlElement.classList.add('gui-slider-container', 'gui-cs03-slider');
    htmlElement.style.position = 'absolute';
    htmlElement.style.overflow = 'visible';

    const paramId = mergedAttributes['param'] || (DomUtils.getParamValue ? DomUtils.getParamValue(xmlNode, currentParams ? currentParams.paramOffset : 0) : '');
    const vmin = parseFloat(mergedAttributes['vmin'] || '0');
    const vmax = parseFloat(mergedAttributes['vmax'] || '1');
    const vdefault = parseFloat(mergedAttributes['vdefault'] || vmin);
    const isStepped = mergedAttributes['stepped'] === '1';

    // Core Track Layout Properties
    const trackX = parseFloat(mergedAttributes['track_x'] || '0');
    const trackY = parseFloat(mergedAttributes['track_y'] || '0');
    const trackW = parseFloat(mergedAttributes['track_w'] || '10');
    const trackH = parseFloat(mergedAttributes['track_h'] || '100');
    const trackColor = mergedAttributes['trackColor'] || mergedAttributes['trackcolor'] || '#2e2e2e';

    const track = document.createElement('div');
    track.style.position = 'absolute';
    track.style.left = `${trackX}px`;
    track.style.top = `${trackY}px`;
    track.style.width = `${trackW}px`;
    track.style.height = `${trackH}px`;
    track.style.backgroundColor = DomUtils.parseColor ? DomUtils.parseColor(trackColor) : trackColor;
    htmlElement.appendChild(track);

    // Optional Modulation Secondary Track Overlay
    if (mergedAttributes['modTrack_x']) {
        const mtX = parseFloat(mergedAttributes['modTrack_x'] || '0');
        const mtY = parseFloat(mergedAttributes['modTrack_y'] || '0');
        const mtW = parseFloat(mergedAttributes['modTrack_w'] || '2');
        const mtH = parseFloat(mergedAttributes['modTrack_h'] || '100');
        const mtColor = mergedAttributes['modTrackColor'] || '#22222280';

        const modTrack = document.createElement('div');
        modTrack.style.position = 'absolute';
        modTrack.style.left = `${mtX}px`;
        modTrack.style.top = `${mtY}px`;
        modTrack.style.width = `${mtW}px`;
        modTrack.style.height = `${mtH}px`;
        modTrack.style.backgroundColor = DomUtils.parseColor ? DomUtils.parseColor(mtColor) : mtColor;
        htmlElement.appendChild(modTrack);
    }

    // Graphical Knob Handle Initialization
    const knobX = parseFloat(mergedAttributes['knob_x'] || '0');
    const knobW = parseFloat(mergedAttributes['knob_w'] || '10');
    const knobH = parseFloat(mergedAttributes['knob_h'] || '10');
    const knobAsset = mergedAttributes['knob'];

    const knob = document.createElement('div');
    knob.style.position = 'absolute';
    knob.style.left = `${knobX}px`;
    knob.style.width = `${knobW}px`;
    knob.style.height = `${knobH}px`;
    knob.style.cursor = 'grab';
    knob.style.zIndex = '2';

    if (knobAsset) {
        const fullPath = State.normalizePath ? State.normalizePath(knobAsset, State.getCurrentSkinRoot()) : knobAsset;
        const blobUrl = State.getAssetBlobUrl ? State.getAssetBlobUrl(fullPath) : null;
        if (blobUrl) {
            knob.style.backgroundImage = `url(${blobUrl})`;
            knob.style.backgroundSize = '100% 100%';
            knob.style.backgroundRepeat = 'no-repeat';
        } else {
            knob.style.backgroundColor = '#666';
        }
    } else {
        knob.style.backgroundColor = '#888';
    }
    htmlElement.appendChild(knob);

    // Create an active fill overlay mapped directly inside the vertical slider background track
    const fill = document.createElement('div');
    fill.style.position = 'absolute';
    fill.style.left = `${trackX}px`;
    fill.style.width = `${trackW}px`;
    fill.style.pointerEvents = 'none';
    
    const rawFillColor = mergedAttributes['fillColor'] || mergedAttributes['fillcolor'];
    if (rawFillColor) {
        fill.style.backgroundColor = DomUtils.parseColor ? DomUtils.parseColor(rawFillColor) : rawFillColor;
    }
    htmlElement.appendChild(fill);

    const lX = parseFloat(mergedAttributes['label_x'] || '0');
    const lY = parseFloat(mergedAttributes['label_y'] || '0');
    const lW = parseFloat(mergedAttributes['label_w'] || '30');
    const lH = parseFloat(mergedAttributes['label_h'] || '20');

    // Static Text Label Overlay
    let label = null;
    if (mergedAttributes['labelText']) {
        const lColor = mergedAttributes['label_fontColor'] || '#ffffff';
        const lFont = mergedAttributes['label_font'];

        label = document.createElement('div');
        label.style.position = 'absolute';
        label.style.left = `${lX}px`;
        label.style.top = `${lY}px`;
        label.style.width = `${lW}px`;
        label.style.height = `${lH}px`;
        label.style.color = DomUtils.parseColor ? DomUtils.parseColor(lColor) : lColor;
        label.style.textAlign = 'center';
        label.style.display = 'flex';
        label.style.alignItems = 'center';
        label.style.justifyContent = 'center';
        label.style.whiteSpace = 'nowrap';
        label.textContent = mergedAttributes['labelText'];
        label.style.pointerEvents = 'none';

        if (lFont && DomUtils.applyFont) {
            DomUtils.applyFont(label, lFont);
        }
        htmlElement.appendChild(label);
    }

    // Active Live Parameter Value Display Layer
    let valueDisplay = null;
    if (mergedAttributes['showValueTextOnHL'] === '1' || mergedAttributes['showValueTextMod'] === '1') {
        valueDisplay = document.createElement('div');
        valueDisplay.style.position = 'absolute';
        valueDisplay.style.left = `${lX}px`;
        valueDisplay.style.top = `${lY}px`;
        valueDisplay.style.width = `${lW}px`;
        valueDisplay.style.height = `${lH}px`;
        valueDisplay.style.textAlign = 'center';
        valueDisplay.style.display = 'none'; // hidden by default
        valueDisplay.style.alignItems = 'center';
        valueDisplay.style.justifyContent = 'center';
        valueDisplay.style.whiteSpace = 'nowrap';
        valueDisplay.style.pointerEvents = 'none';
        valueDisplay.style.color = DomUtils.parseColor ? DomUtils.parseColor(mergedAttributes['value_fontColor'] || '#ffffff') : '#ffffff';
        
        const vFont = mergedAttributes['value_font'];
        if (vFont && DomUtils.applyFont) {
            DomUtils.applyFont(valueDisplay, vFont);
        }
        htmlElement.appendChild(valueDisplay);
    }

    htmlElement.dataset.param = paramId || '';
    htmlElement.dataset.currentValue = vdefault;

    let isHovered = false;

    if (mergedAttributes['showValueTextOnHL'] === '1') {
        htmlElement.addEventListener('mouseenter', () => {
            isHovered = true;
            syncVisuals();
        });
        htmlElement.addEventListener('mouseleave', () => {
            isHovered = false;
            syncVisuals();
        });
    }

    const syncVisuals = () => {
        let val = parseFloat(htmlElement.dataset.currentValue);
        if (isNaN(val)) val = vdefault;

        const range = vmax - vmin;
        const pct = range > 0 ? (val - vmin) / range : 0;
        const constrainedPct = Math.max(0, Math.min(1, pct));

        const availableHeight = trackH - knobH;
        const finalTop = trackY + availableHeight * (1 - constrainedPct);
        knob.style.top = `${finalTop}px`;

        // Synchronize active fill height matching the precise bottom-up knob frame trajectory
        const fillTop = trackY + availableHeight * (1 - constrainedPct) + (knobH / 2);
        const fillHeight = (trackY + trackH) - fillTop;
        fill.style.top = `${fillTop}px`;
        fill.style.height = `${Math.max(0, fillHeight)}px`;

        const formattedVal = isStepped ? Math.round(val).toString() : val.toFixed(1);

        if (valueDisplay) {
            valueDisplay.textContent = formattedVal;
        }

        if (label && valueDisplay && mergedAttributes['showValueTextOnHL'] === '1') {
            if (isHovered) {
                label.style.display = 'none';
                valueDisplay.style.display = 'flex';
            } else {
                label.style.display = 'flex';
                valueDisplay.style.display = 'none';
            }
        }
    };

    htmlElement.updateVisualState = syncVisuals;
    syncVisuals();

    const observer = new MutationObserver(syncVisuals);
    observer.observe(knob, { attributes: true, attributeFilter: ['style'] });
    observer.observe(htmlElement, { attributes: true, attributeFilter: ['data-current-value'] });

    const handleDrag = (clientY) => {
        const rect = htmlElement.getBoundingClientRect();
        const relativeY = clientY - rect.top;
        const availableHeight = trackH - knobH;
        if (availableHeight <= 0) return;

        let pct = 1 - ((relativeY - trackY) / availableHeight);
        pct = Math.max(0, Math.min(1, pct));

        let newVal = vmin + pct * (vmax - vmin);
        if (isStepped) {
            newVal = Math.round(newVal);
        }

        htmlElement.dataset.currentValue = newVal;
        if (paramId && typeof State?.setElementState === 'function') {
            State.setElementState(paramId, newVal);
        }
        if (typeof window?.updateControllerVisibilities === 'function') {
            window.updateControllerVisibilities();
        }
        syncVisuals();
    };

    let isDragging = false;

    const onMouseDown = (e) => {
        isDragging = true;
        handleDrag(e.clientY);
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    };

    const onMouseMove = (e) => {
        if (!isDragging) return;
        handleDrag(e.clientY);
    };

    const onMouseUp = () => {
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    };

    knob.addEventListener('mousedown', onMouseDown);
    if (mergedAttributes['clickOnTrack'] === '1') {
        track.addEventListener('mousedown', onMouseDown);
    }

    // Touch Support for Mobile / Canvas Integrations
    knob.addEventListener('touchstart', (e) => {
        isDragging = true;
        handleDrag(e.touches[0].clientY);
        const onTouchMove = (evt) => {
            if (!isDragging) return;
            handleDrag(evt.touches[0].clientY);
        };
        const onTouchEnd = () => {
            isDragging = false;
            document.removeEventListener('touchmove', onTouchMove);
            document.removeEventListener('touchend', onTouchEnd);
        };
        document.addEventListener('touchmove', onTouchMove, { passive: true });
        document.addEventListener('touchend', onTouchEnd);
    }, { passive: true });

    return {
        htmlElement: htmlElement,
        mainElementForAttributes: htmlElement,
        requiresRecursiveRender: false,
        postProcessFunction: null
    };
}