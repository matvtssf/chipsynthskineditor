// File: cs/guiBuilder.js
/**
 * guiBuilder.js
 * Handles the overall GUI building process, including parsing the main XML,
 * processing styles and fonts, and initiating element rendering.
 * MODIFIED: Adapted to new HTML structure: main-content-area (scroll viewport) >
 * gui-zoom-canvas (2500x1500, scaled) > skin-container-actual (XML sized).
 * - Uses new DomUtils getters.
 * - Applies dimensions and background to skin-container-actual.
 * - Renders elements into skin-container-actual.
 * - Implements initial scroll centering on main-content-area.
 * MODIFIED: Style parsing to ensure first definition wins within a single block.
 */
import * as State from './state.js';
import { getDirectory } from './state.js'; // Keep this import, might be needed elsewhere
import * as DomUtils from './domUtils.js';
import { renderElement } from './uiRenderer.js';
import { setupButtonListeners } from '../interactions/buttonInteractions.js';
import { initializeAllContainerStates } from './visibilityController.js';

/**
 * Builds the GUI based on the provided XML content and path.
 * @param {string} mainGuiXmlContent - The string content of the main GUI XML file.
 * @param {string} mainGuiXmlPath - The path of the main GUI XML file ACTUALLY LOADED (could be fallback).
 */
export function buildGui(mainGuiXmlContent, mainGuiXmlPath) {
    console.log(`[guiBuilder] Starting GUI build from: ${mainGuiXmlPath}`);
    const mainViewport = DomUtils.getMainContentArea(); 
    const zoomCanvas = DomUtils.getGuiZoomCanvas(); 
    const skinHolder = DomUtils.getSkinContainerActual(); 
    const dynamicStyles = DomUtils.getDynamicStyles();

    if (!mainViewport || !zoomCanvas || !skinHolder || !dynamicStyles) {
        DomUtils.logError('[guiBuilder] Critical: Core GUI layout elements (mainViewport, zoomCanvas, skinHolder, or dynamicStyles) not found.', null);
        DomUtils.updateStatus('Error: Core GUI elements missing.', 0);
        return;
    }

    skinHolder.innerHTML = ''; 
    dynamicStyles.textContent = '';
    State.setFontMap(new Map());
    State.setGlobalGuiDefaults({});
    State.setSkinDefaultBackgroundColor(null);
    State.setStyles({}); // Clear existing styles at the beginning of a build
    State.addUsedFile('xml', mainGuiXmlPath); // Track the main XML being loaded

    if (window.visibilityController && typeof window.visibilityController.clearRegisteredContainers === 'function') {
        window.visibilityController.clearRegisteredContainers();
    } else {
        console.warn("[guiBuilder] visibilityController.clearRegisteredContainers not available during reset.");
    }
    
    // Clear dynamic routing managers for clean reload
    window.csViewConfigManagers = [];
    window.csViewConfigSets = {};

    mainViewport.classList.remove('loaded');
    mainViewport.scrollTop = 0;
    mainViewport.scrollLeft = 0;

    try {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(mainGuiXmlContent, "application/xml");
        const parseError = xmlDoc.querySelector("parsererror");
        if (parseError) {
            throw new Error(`Main GUI XML parse error: ${parseError.textContent}`);
        }
        const guiNode = xmlDoc.documentElement;
        if (!guiNode || guiNode.tagName !== 'GUI') {
            throw new Error("No valid <GUI> root element found.");
        }

        const guiWidthAttr = guiNode.getAttribute('w');
        const guiHeightAttr = guiNode.getAttribute('h');
        const guiWidth = guiWidthAttr ? parseInt(guiWidthAttr, 10) : 1024;
        const guiHeight = guiHeightAttr ? parseInt(guiHeightAttr, 10) : 630;

        const globalDefaults = {};
        const defaultBg = guiNode.getAttribute('color_back') || guiNode.getAttribute('backgroundColor') || '#565d82FF';
        globalDefaults['color_back'] = defaultBg;
        const defaultTextColor = guiNode.getAttribute('color_text') || guiNode.getAttribute('textColor') || '#FFFFFFFF';
        globalDefaults['color_text'] = defaultTextColor;

        State.setBaseGuiDimensions(guiWidth, guiHeight);
        State.setGlobalGuiDefaults(globalDefaults);
        State.setSkinDefaultBackgroundColor(defaultBg); 

        skinHolder.style.width = `${guiWidth}px`;
        skinHolder.style.height = `${guiHeight}px`;
        if (defaultBg) {
            skinHolder.style.backgroundColor = DomUtils.parseColor(defaultBg);
        } else {
            skinHolder.style.backgroundColor = 'transparent'; 
        }

        mainViewport.classList.add('loaded'); 
        DomUtils.applyCurrentBackgroundColor(); 

        console.log("[guiBuilder] Processing <Styles> includes...");
        const styleIncludes = guiNode.querySelectorAll('Styles'); // Selects <Styles> tags
        styleIncludes.forEach(styleNode => {
            const stylePathAttr = styleNode.getAttribute('path');
            if (stylePathAttr) { // External <Styles path="...">
                const xmlDir = getDirectory(mainGuiXmlPath);
                const targetStylePath = State.normalizePath(xmlDir ? `${xmlDir}/${stylePathAttr}` : stylePathAttr);
                const styleContent = State.getFileContent(targetStylePath);
                if (styleContent) {
                    State.addUsedFile(targetStylePath);
                    parseStylesXml(styleContent, targetStylePath); // Process this file's styles
                } else {
                    DomUtils.logError(`[guiBuilder] Styles file NOT FOUND: ${targetStylePath}`, null);
                }
            } else { // Inline <Styles> block (contains <Style> and <StyleMacro> children)
                 parseStylesXmlFromNode(styleNode, `${mainGuiXmlPath} (inline <Styles> block)`);
            }
        });
        
        // Process top-level <Style> and <StyleMacro> direct children of <GUI>
         const topLevelStyleNodes = Array.from(guiNode.children).filter(node => node.tagName === 'Style' || node.tagName === 'StyleMacro');
         if (topLevelStyleNodes.length > 0) {
             const tempParent = xmlDoc.createElement('TempStylesRoot'); // Create a temporary parent for parsing
             topLevelStyleNodes.forEach(node => tempParent.appendChild(node.cloneNode(true)));
             parseStylesXmlFromNode(tempParent, `${mainGuiXmlPath} (top-level <Style>/<StyleMacro> tags)`);
         }

        parseFontDefinitions(guiNode, dynamicStyles);

        console.log("[guiBuilder] Rendering child elements into skinHolder...");
        const childNodes = guiNode.childNodes;
        for (let i = 0; i < childNodes.length; i++) {
            const child = childNodes[i];
            if (child.nodeType === Node.ELEMENT_NODE) {
                if (!['Styles', 'Font', 'Property', 'Define', 'XMLMacroText', 'Style', 'StyleMacro'].includes(child.tagName)) {
                    renderElement(child, skinHolder, {}, mainGuiXmlPath);
                }
            }
        }

        console.log("[guiBuilder] GUI build process completed.");
        initializeAllContainerStates();
        setupButtonListeners();
        DomUtils.updateStatus(`Loaded: ${mainGuiXmlPath}`, 5000);

        requestAnimationFrame(() => {
            if (!mainViewport || !zoomCanvas || !skinHolder) return; 

            const viewportWidth = mainViewport.clientWidth;
            const viewportHeight = mainViewport.clientHeight;
            const skinHolderCenterXInZoomCanvas = (zoomCanvas.offsetWidth - skinHolder.offsetWidth) / 2 + (skinHolder.offsetWidth / 2);
            const skinHolderCenterYInZoomCanvas = (zoomCanvas.offsetHeight - skinHolder.offsetHeight) / 2 + (skinHolder.offsetHeight / 2);
            
            mainViewport.scrollLeft = skinHolderCenterXInZoomCanvas - (viewportWidth / 2);
            mainViewport.scrollTop = skinHolderCenterYInZoomCanvas - (viewportHeight / 2);

            console.log(`[guiBuilder] Initial scroll set for mainViewport: L=${mainViewport.scrollLeft}, T=${mainViewport.scrollTop}`);
        });

    } catch (error) {
        DomUtils.logError(`[guiBuilder] Error during GUI build from ${mainGuiXmlPath}`, error, true);
        DomUtils.updateStatus('GUI Build Error! Check console.', 0);
        DomUtils.showToast(`GUI Build Error: ${error.message}. Check console.`, 'error', 0);
        skinHolder.innerHTML = '<p style="color:red; text-align:center; padding: 20px;">Error building GUI. Check console for details.</p>';
    }
}

function parseStylesXml(xmlContent, sourcePath) {
    try {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlContent, "application/xml");
        const parseError = xmlDoc.querySelector("parsererror");
        if (parseError) {
            throw new Error(`Style XML parse error in ${sourcePath}: ${parseError.textContent}`);
        }
        const stylesRoot = xmlDoc.documentElement;
        if (!stylesRoot || (stylesRoot.tagName !== 'Styles' && stylesRoot.tagName !== 'StyleSheet')) { // Support <StyleSheet> as root too
            console.warn(`[guiBuilder] Styles file ${sourcePath} does not have <Styles> or <StyleSheet> root. Parsing direct children if any, or assuming it's a collection of <Style> tags.`);
        }
        // Pass stylesRoot which could be <Styles>, <StyleSheet>, or the documentElement if neither.
        parseStylesXmlFromNode(stylesRoot, sourcePath); 
    } catch (error) {
        DomUtils.logError(`[guiBuilder] Failed to parse styles XML from ${sourcePath}`, error);
    }
}

function parseStylesXmlFromNode(parentNode, sourcePath = 'inline') {
     if (!parentNode) return;
     
     // Get a fresh copy of current global styles for this parsing pass
     let currentGlobalStyles = State.getStyles() || {};
     const macros = {}; // Macros are local to this specific Styles block/file
     const stylesFromThisNode = {}; // Styles defined in this specific block/file

     // First pass: Collect all StyleMacros within this parentNode
     const directMacroNodes = Array.from(parentNode.children).filter(node => node.tagName === 'StyleMacro');
     directMacroNodes.forEach(macroNode => {
         const name = macroNode.getAttribute('name');
         const value = macroNode.getAttribute('value');
         if (name && value) {
             if (!macros.hasOwnProperty(name)) { // First definition wins for macros within this block
                 macros[name] = value;
             }
         }
     });

     // Second pass: Collect all Styles, applying macros, first definition wins for styles within this block
     const directStyleNodes = Array.from(parentNode.children).filter(node => node.tagName === 'Style');
     directStyleNodes.forEach(styleNode => {
         const name = styleNode.getAttribute('name');
         if (name) {
             if (!stylesFromThisNode.hasOwnProperty(name)) { // First definition of a style name wins within this current block
                 const attributes = {};
                 for (let i = 0; i < styleNode.attributes.length; i++) {
                     const attr = styleNode.attributes[i];
                     if (attr.name !== 'name') { // Don't copy the 'name' attribute itself into the style's attributes
                         let value = attr.value;
                         // Macro replacement
                         if (value && typeof value === 'string' && value.includes('@')) {
                             value = value.replace(/@(\w+)/g, (match, macroName) => {
                                 return macros[macroName] !== undefined ? macros[macroName] : match;
                             });
                         }
                         attributes[attr.name] = value;
                     }
                 }
                 stylesFromThisNode[name] = attributes;
             } else {
                 console.warn(`[guiBuilder] Style "${name}" in "${sourcePath}" redefined. Using first definition.`);
             }
         }
     });

     // Merge stylesFromThisNode into a new object based on currentGlobalStyles
     // This ensures that styles from the current node/file override existing global styles if names clash.
     // To make *earlier* global styles win (first definition globally wins), the order would be:
     // const mergedStyles = { ...stylesFromThisNode, ...currentGlobalStyles };
     // However, standard CSS cascade is usually later definitions win.
     // The user request implies "first definition *within a file* wins", but "later *files/blocks* override earlier ones".
     // So, the current merge `{ ...currentGlobalStyles, ...stylesFromThisNode }` is correct for the cascade part.
     // The `!stylesFromThisNode.hasOwnProperty(name)` handles "first wins within this block".
     const newGlobalStyles = { ...currentGlobalStyles, ...stylesFromThisNode };
     State.setStyles(newGlobalStyles);
     // console.log(`[guiBuilder] Styles updated from "${sourcePath}". Total styles: ${Object.keys(State.getStyles()).length}`);
}


function parseFontDefinitions(guiNode, dynamicStylesElement) {
    const fontMap = new Map();
    const fontNodes = guiNode.querySelectorAll('Font');
    console.log(`[guiBuilder] Found ${fontNodes.length} <Font> definitions.`);

    fontNodes.forEach(fontNode => {
        const alias = fontNode.getAttribute('alias');
        const filename = fontNode.getAttribute('filename');
        const nameWin = fontNode.getAttribute('name_windows');
        const nameMac = fontNode.getAttribute('name_osx');
        const sizeWin = fontNode.getAttribute('size_windows');
        const styleWin = fontNode.getAttribute('style_windows');
        const sizeMac = fontNode.getAttribute('size_osx');
        const styleMac = fontNode.getAttribute('style_osx');

        const fontData = {
            alias: alias,
            filename: filename,
            name_windows: nameWin,
            name_osx: nameMac,
            size: sizeWin || sizeMac || null,
            style: styleWin || styleMac || null,
            weight: (styleWin?.toLowerCase().includes('bold') || styleMac?.toLowerCase().includes('bold')) ? 'bold' : 'normal',
            fontStyle: (styleWin?.toLowerCase().includes('italic') || styleMac?.toLowerCase().includes('italic')) ? 'italic' : 'normal'
        };

        if (alias) {
            if (filename) {
                const currentSkinRoot = State.getCurrentSkinRoot() || '';
                const normalizedFontPath = State.normalizePath(filename, currentSkinRoot); // Ensure font path is relative to skin root if applicable
                const fontUrl = State.getAssetBlobUrl(normalizedFontPath);
                if (fontUrl) {
                    State.addUsedFile(normalizedFontPath);
                    try {
                        const safeFamilyName = alias; // Use alias directly as family name
                        const format = filename.endsWith('.otf') ? 'opentype' : 'truetype';
                        const fontFaceRule = `\n@font-face {\n    font-family: "${safeFamilyName}";\n    src: url('${fontUrl}') format('${format}');\n    font-weight: ${fontData.weight};\n    font-style: ${fontData.fontStyle};\n}\n`;
                        dynamicStylesElement.textContent += fontFaceRule;
                        fontData.family = safeFamilyName; // Store the CSS family name
                        console.log(`[guiBuilder] Added @font-face for alias "${alias}" using ${normalizedFontPath}. CSS family: "${safeFamilyName}"`);
                    } catch(e) {
                        DomUtils.logError(`Failed to create @font-face for ${alias}/${normalizedFontPath}`, e);
                    }
                } else {
                    console.warn(`[guiBuilder] Font file blob URL not found for "${normalizedFontPath}" (alias: "${alias}"). Style might fall back.`);
                    fontData.family = nameWin || nameMac || 'sans-serif'; // Fallback system font
                }
            } else { // No filename, use system font names
                fontData.family = nameWin || nameMac || 'sans-serif';
                console.log(`[guiBuilder] Font alias "${alias}" relies on system font: ${fontData.family}`);
            }
            fontMap.set(alias, fontData);
        } else {
            console.warn("[guiBuilder] Found <Font> tag without an 'alias'. Skipping.");
        }
    });
    State.setFontMap(fontMap);
    console.log(`[guiBuilder] Font map updated. Total fonts: ${fontMap.size}`);
}